public class CompteOperationException extends Exception {

    public CompteOperationException(){
    }

    public CompteOperationException (String message) {
        System.out.println(message);
    }
}


