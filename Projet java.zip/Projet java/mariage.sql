-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  lun. 07 déc. 2020 à 10:16
-- Version du serveur :  5.7.23
-- Version de PHP :  7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `mariage`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_utilisateur` varchar(30) NOT NULL,
  `motdepasse` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id`, `nom_utilisateur`, `motdepasse`) VALUES
(1, 'Believe', 12345678),
(2, 'Marlene', 12345678);

-- --------------------------------------------------------

--
-- Structure de la table `femme`
--

DROP TABLE IF EXISTS `femme`;
CREATE TABLE IF NOT EXISTS `femme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomsF` varchar(30) NOT NULL,
  `lieuEtDate` varchar(50) NOT NULL,
  `pere` varchar(50) NOT NULL,
  `mere` varchar(50) NOT NULL,
  `profession` varchar(50) NOT NULL,
  `nationalite` varchar(50) NOT NULL,
  `village` varchar(50) NOT NULL,
  `territoire` varchar(50) NOT NULL,
  `districtEtProvince` varchar(50) NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `nbreEnfant` int(11) NOT NULL,
  `telephone` int(11) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `homme`
--

DROP TABLE IF EXISTS `homme`;
CREATE TABLE IF NOT EXISTS `homme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomsH` varchar(30) NOT NULL,
  `lieuEtDate` varchar(30) NOT NULL,
  `pere` varchar(50) NOT NULL,
  `mere` varchar(50) NOT NULL,
  `profession` varchar(50) NOT NULL,
  `nationalite` varchar(30) NOT NULL,
  `village` varchar(30) NOT NULL,
  `territoire` varchar(30) NOT NULL,
  `districtEtProvince` varchar(30) NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `nbreEnfant` int(30) NOT NULL,
  `telephone` int(11) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `mariage`
--

DROP TABLE IF EXISTS `mariage`;
CREATE TABLE IF NOT EXISTS `mariage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idHomme` int(11) NOT NULL,
  `idFemme` int(11) NOT NULL,
  `dot` int(11) NOT NULL,
  `nomTemoin` varchar(50) NOT NULL,
  `adresseTemoin` varchar(50) NOT NULL,
  `numeroTemoins` int(11) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
