/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Believe Luyeye
 */
public class Personne {
    private int nature;
    private String noms;
    private String lieuEtDate;
    
    private String nomPere;
    private String nomMere;
    
    private String profession;
    private String nationalite;
    private String village;
    private String territoire;
    private String districtEtProvince;
    
    private String adresse;
    private int nbreEnfant;
    private int telephone;

    public Personne(int nature, String noms, String lieuEtDate, String nomPere, String nomMere, String profession, String nationalite, String village, String territoire, String districtEtProvince, String adresse, int nbreEnfant, int telephone) {
        this.nature = nature;
        this.noms = noms;
        this.lieuEtDate = lieuEtDate;
        this.nomPere = nomPere;
        this.nomMere = nomMere;
        this.profession = profession;
        this.nationalite = nationalite;
        this.village = village;
        this.territoire = territoire;
        this.districtEtProvince = districtEtProvince;
        this.adresse = adresse;
        this.nbreEnfant = nbreEnfant;
        this.telephone = telephone;
    }

    
    
    
    public int enregistrer() {
        ResultSet rs = null;
        int id = 0;
        String req = "";
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mariage", "root", "");
            Statement st = con.createStatement();
            
            // on insert les informations d'une personne dans la base de données
            
            if(nature == 1) {
                req = "INSERT INTO homme (nomsH, lieuEtDate, pere, mere, profession, nationalite, village, territoire, districtEtProvince, adresse, nbreEnfant, telephone)VALUES ('"+noms+"', '"+lieuEtDate+"', '"
                    +nomPere+"', '"+nomMere+"', '"+profession+"', '"+nationalite+"', '"
                    +village+"', '"+territoire+"', '"+districtEtProvince+"', '"
                    +adresse+"',"+nbreEnfant+", "+telephone+")";
            }
            else {
                req = "INSERT INTO femme (nomsF, lieuEtDate, pere, mere, profession, nationalite, village, territoire, districtEtProvince, adresse, nbreEnfant, telephone)VALUES ('"+noms+"', '"+lieuEtDate+"', '"
                    +nomPere+"', '"+nomMere+"', '"+profession+"', '"+nationalite+"', '"
                    +village+"', '"+territoire+"', '"+districtEtProvince+"', '"
                    +adresse+"',"+nbreEnfant+", "+telephone+")";
            }
            
            st.executeUpdate(req);
           
            // Ici on récupère son id
            if(nature == 1) {
                req = "SELECT id FROM homme WHERE id = LAST_INSERT_ID()";
            }
            else {
                req = "SELECT id FROM femme WHERE id = LAST_INSERT_ID()";
            }
            
            rs = st.executeQuery(req);
            
            while(rs.next()) {
                id = Integer.parseInt(rs.getString("id"));
            }            
            
            JOptionPane.showMessageDialog(null, "Opération réussi !!");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erreur => " + e);
        }
        
        return id;
    }
    
    
}
