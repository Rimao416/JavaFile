/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Believe Luyeye
 */
public class Mariage {
    private int idHomme;
    private int idFemme;
    private int dot;
    private String nomTemoin;
    private String adresseTemoin;
    private int numeroTemoins;
    
    
    public Mariage() {
        
    }
    
    public Mariage(int idHomme, int idFemme, int dot, String nomTemoin, String adresseTemoin, int numeroTemoins) {
        this.idHomme = idHomme;
        this.idFemme = idFemme;
        this.dot = dot;
        this.nomTemoin = nomTemoin;
        this.adresseTemoin = adresseTemoin;
        this.numeroTemoins = numeroTemoins;
    }
    
    
    public void enregistrer() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mariage", "root", "");
            Statement st = con.createStatement();
            
            String req = "INSERT INTO mariage (idHomme, idFemme, dot, nomTemoin, adresseTemoin, numeroTemoins) VALUES ("
                    +idHomme+", "+idFemme+", "+dot+", '"+nomTemoin+"', '"+adresseTemoin+"', "+numeroTemoins+")";
            
            st.executeUpdate(req);
            
            JOptionPane.showMessageDialog(null, "Opération réussi !!!");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erreur => " + e);
        }
    }
    
    public ResultSet voirMariage() {
        ResultSet rs = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mariage", "root", "");
            Statement st = con.createStatement();
            
            String req = "select * from  mariage join homme on homme.id = mariage.idHomme join femme on femme.id = mariage.idFemme";
            
            rs = st.executeQuery(req);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erreur => " + e);
        }
        
        return rs;
    }
    
    
    
      
    
}
